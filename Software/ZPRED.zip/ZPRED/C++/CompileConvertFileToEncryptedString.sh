clear
G_File=/usr/bin/g++
Fldr=$(pwd)/

C_File=$Fldr"convertFileToEncryptedString.cpp"
X_File=$Fldr"convertFileToEncryptedString.exe"

#rm -f $X_File
# Compile & Run get_SES_Shell
$G_File -std=gnu++11 -o $X_File $C_File -lm -w -lrt -lcrypto
$X_File -i ZPRED.cpp -o Output.txt
