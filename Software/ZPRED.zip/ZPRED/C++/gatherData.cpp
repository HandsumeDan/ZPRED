# include <algorithm>
# include <cmath>
# include <cstdio>					// defines remove
# include <cstdlib>
# include <cstring>
# include <ctime>					// defines clock_t, clock, CLOCKS_PER_SEC
# include <fstream>
# include <iostream>
# include <sstream>
# include <string>
# include <thread>
# include <utility>
# include <vector>
//# include <fcntl.h>					// Defines O_CREAT flag
//# include <sys/reg.h>
//# include <sys/syscall.h>			// Defines OS System Calls
//# include <sys/ptrace.h>
//# include <sys/types.h>
//# include <sys/user.h>
//# include <sys/wait.h>
//# include <sys/stat.h>				// Defines chmod function
//# include <boost/filesystem.hpp>		// create_directory
//# include <boost/numeric/odeint.hpp>
//# include <openssl/conf.h>
//# include <openssl/evp.h>				// ciphers and message digests
//# include <openssl/err.h>
//# include <openssl/ssl.h>				// for libssl
# include <unistd.h>
//# include "ap.h"
//# include "solvers.h"
//# include "stdafx.h"

using namespace std;
//using namespace boost::numeric::odeint;

// Acceptable Deviation During Newton-Ralphson Iteration
# define ACCEPTED_ERROR_PERCENT 5e-4
// Default Length of a Number to consider for cnvrtNumToStrng
# define BUFFER_SIZE 12
// Number of digits behind  point for ion radii and inflation distance/slip plane position
# define DISTANCE_SIG_FIGS 2
// Number of digits behind  point for solvent dielectric constant
# define ER_SIG_FIGS 2
// Default Number of Threads to Execute ZPRED on (if not user specified)
# define MAX_THREADS 3
// Maximum Number of Rows for Terminal Display
# define MAX_DISPLAY_ROWS 25
// Maximum Number of Columns for Terminal Display
# define MAX_DISPLAY_COLS 6
// Maximum Number of Iterations to Solve for PBE Coefficient
# define MAX_PBE_ITERATIONS 1000
// Maximu Number of File Open Attempts
# define MAX_FILE_OPEN_ATTEMPTS 100000

// Physical Constants
// Avogadro's Number (Particles per mole)
# define Na 6.022140857e23
// Universal Gas Constant (Joule/(Kelvin*mol))
# define Rg 8.3144598
//Boltzmann Constant (Joule/Kelvin)
# define kb Rg/Na
//Electron (or Elementary) Charge (Coulomb)
# define ec 1.6021766208e-19
// PI
# define pi 3.14159265358979323846
// Permeability of Free Space (Tesla*meter/Ampere)
# define uo pi*0.0000004
// Speed of Light in Vacuum (meter/second)
# define sol 299792458
// Permittivity of Free Space (Farad/meter)
# define eo 1/(uo*sol*sol)

typedef vector<double> state_type;


struct Error
{double absolute;double relative;double a_x;double a_dxdt;};


struct Reference
{double** E;double** y;double* ka;int numPlots;int* numPnts;};

// ZPRED Component Software Executables
struct softwareComponents
{string apbsExecutable;string multivalueExecutable;string hydroproExecutable;string msmsExecutable;string msmsAtmTypeNumbers;string msmsPdbToXyzr;string msmsPdbToXyzrn;string pdb2pqr;};

// MSMS Input Parameter Data Class
struct msmsInput
{string PDB;string pdbFile;string msmsFldr;string pdb_msmsFldr;string pdb_surfFldr;string surfPointDensity;string surfPointHiDensity;string probeRadius;string PDB_TO_XYZRN;string MSMS;};

// ZPRED Input Parameter Data Structure Array (for taking data from GUI)
struct zInput
{int numSolCond;
string* id;
double* shapeFactor;
double* molecularWeight;
string* files;
int numFiles;
string name;
string* pH;
string** solvent;
int* numSolvent;
double** solventConc;
string* solventConcType;
string** solute;
int* numSolute;
double** soluteConc;
string* soluteConcType;
double* temperature;
double* proteinConc;
string outputTitle;
string* apbsWriteTypes;
int numApbsWriteTypes;
softwareComponents SC;
msmsInput msms;
string hydroproCalcType;
string forceField;
bool saveTemps;
string pdie;
string dime_x;string dime_y;string dime_z;
bool RUN_APBS;bool RUN_PDB2PQR;bool RUN_HYDROPRO;bool RUN_HULLRAD;bool RUN_ZPRED;bool RUN_COLLIDE;
int maxThreads;
// User Specified Values (-1 if not specified)
double* dielectric;double* viscosity;double* density;double* inflationDistance;
// Generate Pot Profile
bool* GENERATE_POT_PROFILE;
string plot;};

// ZPRED Input Parameter Structure Array for Parallel Execution of the Problem (each represents only one file and solution condition)
struct zExeInput
{string id;
string file;
string pH;
string* solvent;
int numSolvent;
double* solventConc;
string solventConcType;
string* solute;
int numSolute;
double* soluteConc;
string soluteConcType;
double temperature;
double proteinConc;
string outputTitle;
string* apbsWriteTypes;
int numApbsWriteTypes;
softwareComponents SC;
msmsInput msms;
string hydroproCalcType;
string forceField;
bool saveTemps;
string pdie;
string dime_x;string dime_y;string dime_z;
bool RUN_APBS;bool RUN_PDB2PQR;bool RUN_HYDROPRO;bool RUN_HULLRAD;bool RUN_ZPRED;bool RUN_COLLIDE;
int maxThreads;
// User Specified Values (-1 if not specified)
double dielectric;double viscosity;double density;double inflationDistance;
// Generate Pot Profile
bool GENERATE_POT_PROFILE;
};

// Single Solution Properties Data Structure Array
struct solProp
{string pH;string temperature;string dielectric;string viscosity;string density;int numSolute;string* solute;string* soluteConc;string debyeLength;int numSolvent;string* solvent;string* solventConc;};

// Total Solution Properties Data Structure Array
struct allSolProp
{string* pH;string* temperature;string* dielectric;string* viscosity;string* density;int numSolute;string** solute;string** soluteConc;string* debyeLength;int numSolvent;string* solvent;string* solventConc;};

struct electricProfile
{double* position;double* potential;int numPnts;};

// Single ZPRED Output Data Structure Array
struct zOutput
{string proteinName;string solCondNum;double proteinRadius;double solvatedRadius;double zetaPotential;string Xsp;double charge;double semMobility;double henryMobility;double kuwabaraMobility;double diffusivity;solProp solution;electricProfile EP;};

// COLLIDE Input Data Structure Array
struct colInput
{int numSols;string* pRadius;double* proteinRadius;double* proteinRadiusStd;string* sRadius;double* solvatedRadius;double* solvatedRadiusStd;string* zPotential;double* zetaPotential;double* zetaPotentialStd;string* chrg;double* charge;double* chargeStd;string* eMob;double* mobility;double* mobilityStd;string* diff;double* diffusivity;double* diffusivityStd;allSolProp solution;double* collisionEfficiency;double* coagulationTime;};

// General Vector
struct Vec
{double x;double y;double z;};

// String Vector
struct strVec
{string x;string y;string z;};

string getBaseFolder(string f);
string checkWhiteSpaceInFilePath(string iFile);
double interpolate(double x,double x1,double x2,double y1,double y2);
string array2String(int* Data,int numPnts,string delimiter);
string checkFilePathParantheses(string f);
bool IN_STRING_ARRAY(string X,string* L,int N);
bool IN_LIST(string X,string list,int N,string delimiter);
void copyFile(string inFile,string outFile);
string makeUpperCase(string X);
string makeWhiteSpace(int Sz);
string makeHTMLWhiteSpace(int Sz);
zInput read_zpred_input_file(string inFile);
string cnvrtNumToStrng(int Num,int numberAfterDecimalpoint);
string cnvrtNumToStrng(double Num,int numberAfterDecimalpoint);
string cnvrtNumToStrng(long double Num,int numberAfterDecimalpoint);
string cnvrtNumToStrng(float Num,int numberAfterDecimalpoint);
int count_delimiter(string Data,string delimiter);
void erase_display();
string getFileName(string filePath);
double* fill_double_array(string Data,int numPnts,string delimiter);
int* fill_int_array(string Data,int numPnts,string delimiter);
string* fill_string_array(string Data,int numPnts,string delimiter);
string formatNumberString(string Num);
long getFileSize(string inFile);
string repeatString(string Input,int Num);
double calc_distance(Vec Vec1,Vec Vec2);
zOutput read_zpred_output_file(string zOutFile);
double calc_std_dev(double* X,int Sz,double Avg);
double calc_average(double* X,int Sz);

int main(int argc,char *argv[])
{	string inFile,outFile,zOutListFile;
	int ch;
	while((ch=getopt(argc,argv,"i:o:z:"))!=EOF)
		{switch(ch)
			{case 'i':
				// ZPRED Input File
				inFile=optarg;
				break;
			case 'o':
				// ZPRED Output File
				outFile=optarg;
				break;
			case 'z':
				// Specify File Containing List of ZPRED Output Files
				zOutListFile=optarg;
				break;
			default:
				exit(EXIT_FAILURE);}}

	// Get Working Directory of Data
	//string Fldr=get_current_dir_name();Fldr+="/";
	// Go Back 2 Directories
	int pos=zOutListFile.rfind("/");
	string Fldr=zOutListFile.substr(0,pos);//Fldr+="/";
	pos=Fldr.rfind("/");
	Fldr=Fldr.substr(0,pos);Fldr+="/";

	zInput Z=read_zpred_input_file(inFile);
	// Check should be performed by GUI
	//cout<<display_zpred_input(Z)<<endl;
	// Main (ZPRED) Output Folder
	//string outputFldr=Fldr+Z.outputTitle+"/";
	string outputFldr=Fldr;
	// Formatted Data Folders Folder (Also Holds ZPRED Configuration File)	
	string fFldr=Fldr+"Files/";
	// ZPRED Output Folder
	//string zpredFldr=fFldr+"Z/";
	// String Array Delimiter
	string delimiter=";";
	// Determine Total Number of Zeta Potential Calculations
	int totalCalc=Z.numFiles*Z.numSolCond;
	//string display,*cmdStrng,*cmd;
	//vector<thread> t;
	int Counter=0,start=0,end=0,remainingCalc=totalCalc,numCalc=0;
	//cerr<<"ZPRED Timer = "<<((float)Tme)/CLOCKS_PER_SEC<<" s\n";
	// After all ZPRED computations complete, store in user-specified folder (outputTitle parameter in input File)
	//string zpredOutputFile=outputFldr+Z.outputTitle+".txt";
	// Read List of ZPRED Output Files
	//string zOutListFile=fFldr+"zpredOutFilesList.txt",zFile="";	
	ifstream fIn;
	fIn.open(zOutListFile.c_str());
	if(fIn.fail()){cerr<<"ERROR in gatherData!\nZPRED Output File List file could not be opened.\n"<<zOutListFile<<endl;exit(EXIT_FAILURE);}
	int Sz=150000;
	char Val[Sz];
	zOutput zRes;
	// Collect and Average Zeta Potentials of the ensemble of structures for each solution condition
	int* fCounter=new int[Z.numSolCond];
	double** srVal=new double*[Z.numSolCond];	
	double** prVal=new double*[Z.numSolCond];	
	double** zpVal=new double*[Z.numSolCond];
	double** qVal=new double*[Z.numSolCond];
	double** kMobVal=new double*[Z.numSolCond];	
	double** hMobVal=new double*[Z.numSolCond];
	double** semMobVal=new double*[Z.numSolCond];
	double** difVal=new double*[Z.numSolCond];
	double*** electricPotential=new double**[Z.numSolCond];
	double* Sum;
	string*** position=new string**[Z.numSolCond];
	int** numProfilePnts=new int*[Z.numSolCond];
	string* sER=new string[Z.numSolCond];
	string* sDens=new string[Z.numSolCond];
	string* sVisc=new string[Z.numSolCond];
	string* sXsp=new string[Z.numSolCond];
	string* fNm=new string[Z.numFiles];
	for(int i=0;i<Z.numSolCond;i++)
		{fCounter[i]=0;
		srVal[i]=new double[Z.numFiles];
		prVal[i]=new double[Z.numFiles];
		zpVal[i]=new double[Z.numFiles];
		qVal[i]=new double[Z.numFiles];
		semMobVal[i]=new double[Z.numFiles];
		hMobVal[i]=new double[Z.numFiles];
		kMobVal[i]=new double[Z.numFiles];
		difVal[i]=new double[Z.numFiles];
		electricPotential[i]=new double*[Z.numFiles];
		position[i]=new string*[Z.numFiles];
		numProfilePnts[i]=new int[Z.numFiles];}
	int tabIndex;
	string s,zFile;
	fIn.getline(Val,Sz);
	while(!fIn.eof())
		{// Read Single ZPRED Output Results
		zFile=Val;
		zRes=read_zpred_output_file(zFile);
		s=zRes.solCondNum; tabIndex=atoi(s.c_str());
		srVal[tabIndex][fCounter[tabIndex]]=zRes.solvatedRadius;
		prVal[tabIndex][fCounter[tabIndex]]=zRes.proteinRadius;
		zpVal[tabIndex][fCounter[tabIndex]]=zRes.zetaPotential;
		qVal[tabIndex][fCounter[tabIndex]]=zRes.charge;
		semMobVal[tabIndex][fCounter[tabIndex]]=zRes.semMobility;
		hMobVal[tabIndex][fCounter[tabIndex]]=zRes.henryMobility;
		kMobVal[tabIndex][fCounter[tabIndex]]=zRes.kuwabaraMobility;
		difVal[tabIndex][fCounter[tabIndex]]=zRes.diffusivity;
		sER[tabIndex]=zRes.solution.dielectric;
		sDens[tabIndex]=zRes.solution.density;
		sVisc[tabIndex]=zRes.solution.viscosity;
		sXsp[tabIndex]=zRes.Xsp;
		if(zRes.EP.numPnts>0)
			{// Electric Potential Profile Generated
			numProfilePnts[tabIndex][fCounter[tabIndex]]=zRes.EP.numPnts;
			electricPotential[tabIndex][fCounter[tabIndex]]=new double[zRes.EP.numPnts];
			position[tabIndex][fCounter[tabIndex]]=new string[zRes.EP.numPnts];			
			for(int i=0;i<zRes.EP.numPnts;i++)
				{position[tabIndex][fCounter[tabIndex]][i]=cnvrtNumToStrng(zRes.EP.position[i],DISTANCE_SIG_FIGS);
				electricPotential[tabIndex][fCounter[tabIndex]][i]=zRes.EP.potential[i];}
			}
		else
			{numProfilePnts[tabIndex][fCounter[tabIndex]]=0;}
		fNm[fCounter[tabIndex]]=zRes.proteinName;
		fCounter[tabIndex]++;
		fIn.getline(Val,Sz);}
	fIn.close();

	string Output="";
	double avgSR,stdSR,avgPR,stdPR,avgZP,stdZP,avgQ,stdQ,avgkMOB,stdkMOB,avghMOB,stdhMOB,avgsemMOB,stdsemMOB,avgDIF,stdDIF,avgPot,stdPot;
	double* dArr;
	// 9|9|8|9|6|8|8|
	// Determine header Width
	int lnPR=0,lnSR=0,lnZP=0,lnQ=0,lnMOB=0,lnDIF=0;
	string tmp,tmp2,tmp3,tmp4,tmp5,tmp6;
	for(int j=0;j<Z.numFiles;j++)
		{//fNm=cnvrtNumToStrng(j,0);
		//Output+="file #"+fNm+repeatString(" ",3-fNm.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(prVal[0][j],BUFFER_SIZE));
		if(tmp.length()>lnPR){lnPR=tmp.length();}
		tmp2=formatNumberString(cnvrtNumToStrng(srVal[0][j],BUFFER_SIZE));
		if(tmp2.length()>lnSR){lnSR=tmp2.length();}
		tmp3=formatNumberString(cnvrtNumToStrng(zpVal[0][j],BUFFER_SIZE));
		if(tmp3.length()>lnZP){lnZP=tmp3.length();}
		tmp4=formatNumberString(cnvrtNumToStrng(qVal[0][j],BUFFER_SIZE));
		if(tmp4.length()>lnQ){lnQ=tmp4.length();}
		tmp5=formatNumberString(cnvrtNumToStrng(semMobVal[0][j],BUFFER_SIZE));
		if(tmp5.length()>lnMOB){lnMOB=tmp5.length();}
		tmp6=formatNumberString(cnvrtNumToStrng(difVal[0][j],BUFFER_SIZE));
		if(tmp6.length()>lnDIF){lnDIF=tmp6.length();}
		}

	for(int i=0;i<Z.numSolCond;i++)
		{Output+="Solution Condition #"+cnvrtNumToStrng(i,0)+"\n";
		Output+="pH "+Z.pH[i]+" ";
		Output+=formatNumberString(cnvrtNumToStrng(Z.temperature[i],BUFFER_SIZE))+" K\n";
		tmp="";
		for(int a=0;a<Z.numSolvent[i];a++)
			{tmp+=formatNumberString(cnvrtNumToStrng(Z.solventConc[i][a]*100,BUFFER_SIZE));//+"mol% "+Z.solvent[i][a]+"\n";
			tmp2=Z.solventConcType[i];
			if(tmp2.compare("massFraction")==0){tmp+=" mass% ";}
			else if(tmp2.compare("moleFraction")==0){tmp+=" mol% ";}
			else if(tmp2.compare("volumeFraction")==0){tmp+=" vol% ";}
			tmp+=Z.solvent[i][a]+"\n";
			}
		Output+=tmp;
		tmp="";
		for(int a=0;a<Z.numSolute[i];a++){tmp+=formatNumberString(cnvrtNumToStrng(Z.soluteConc[i][a],BUFFER_SIZE))+" M "+Z.solute[i][a]+"\n";}
		Output+=tmp;
		Output+="Relative Dielectric: "+sER[i]+"\n";
		Output+="Density: "+sDens[i]+" kg/L\n";
		Output+="Viscosity: "+sVisc[i]+" Ns/m^2\n";
		Output+="Hydration Layer Thickness: "+sXsp[i]+" A\n";
		Output+="Protein Concentration: "+formatNumberString(cnvrtNumToStrng(Z.proteinConc[i],BUFFER_SIZE))+" g/L\n";
		Output+=repeatString("-",118)+"|\n";
		Output+=repeatString("|",10)+repeatString("-",lnPR)+"|"+repeatString("-",lnSR)+"|"+repeatString("-",lnZP)+"|"+repeatString("-",lnQ)+"|SEM"+repeatString("-",lnMOB-3)+"|Henry"+repeatString("-",lnMOB-5)+"|Kuwabara"+repeatString("-",lnMOB-8)+"|"+repeatString("-",lnDIF)+"|\n";

		Output+=repeatString("|",10)+"Anhydrous"+repeatString("-",lnPR-9)+"|Solvated"+repeatString("-",lnSR-8)+"|Zeta"+repeatString("-",lnZP-4)+"|"+repeatString("-",lnQ)+"|Electro."+repeatString("-",lnMOB-8)+"|Electro."+repeatString("-",lnMOB-8)+"|Electro."+repeatString("-",lnMOB-8)+"|"+repeatString("-",lnDIF)+"|\n";
		Output+=repeatString("|",10)+"Radius"+repeatString("-",lnPR-6)+"|Radius"+repeatString("-",lnSR-6)+"|Potential"+repeatString("-",lnZP-9)+"|Q"+repeatString("-",lnQ-1)+"|Mobility"+repeatString("-",lnMOB-8)+"|Mobility"+repeatString("-",lnMOB-8)+"|Mobility"+repeatString("-",lnMOB-8)+"|Diffusivity"+repeatString("-",lnDIF-11)+"|\n";
		Output+=repeatString("|",10)+"[A]"+repeatString("-",lnPR-3)+"|[A]"+repeatString("-",lnSR-3)+"|[Volts]"+repeatString("-",lnZP-7)+"|"+repeatString("-",lnQ)+"|[umcm/Vs]"+repeatString("-",lnMOB-9)+"|[umcm/Vs]"+repeatString("-",lnMOB-9)+"|[umcm/Vs]"+repeatString("-",lnMOB-9)+"|[m^2/s]"+repeatString("-",lnDIF-7)+"|\n";
		for(int j=0;j<Z.numFiles;j++)
			{tmp=fNm[j];
			Output+=tmp+repeatString(" ",9-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(prVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnPR-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(srVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnSR-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(zpVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnZP-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(qVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnQ-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(semMobVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(hMobVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(kMobVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
			tmp=formatNumberString(cnvrtNumToStrng(difVal[i][j],BUFFER_SIZE));
			Output+=tmp+repeatString(" ",lnDIF-tmp.length())+"|\n";
			}
		Output+=repeatString("-",119)+"\n";
		// Anhydrous Protein Radius
		avgPR=calc_average(prVal[i],Z.numFiles); stdPR=calc_std_dev(prVal[i],Z.numFiles,avgPR);
		// Solvated Protein Radius
		avgSR=calc_average(srVal[i],Z.numFiles); stdSR=calc_std_dev(srVal[i],Z.numFiles,avgSR);
		// Zeta Potential
		avgZP=calc_average(zpVal[i],Z.numFiles); stdZP=calc_std_dev(zpVal[i],Z.numFiles,avgZP);
		// Net Valence
		avgQ=calc_average(qVal[i],Z.numFiles); stdQ=calc_std_dev(qVal[i],Z.numFiles,avgQ);
		// Kuwabara Electrophoretic Mobility
		avgkMOB=calc_average(kMobVal[i],Z.numFiles); stdkMOB=calc_std_dev(kMobVal[i],Z.numFiles,avgkMOB);
		// Henry Electrophoretic Mobility
		avghMOB=calc_average(hMobVal[i],Z.numFiles); stdhMOB=calc_std_dev(hMobVal[i],Z.numFiles,avghMOB);
		// Standard Electrokinetic Model Mobility
		avgsemMOB=calc_average(semMobVal[i],Z.numFiles); stdsemMOB=calc_std_dev(semMobVal[i],Z.numFiles,avgsemMOB);
		// Single Protein Diffusivity
		avgDIF=calc_average(difVal[i],Z.numFiles); stdDIF=calc_std_dev(difVal[i],Z.numFiles,avgDIF);
		// Write Output
		tmp=formatNumberString(cnvrtNumToStrng(avgPR,BUFFER_SIZE));
		Output+="Average  |"+tmp+repeatString(" ",lnPR-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgSR,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnSR-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgZP,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnZP-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgQ,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnQ-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgsemMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avghMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgkMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(avgDIF,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnDIF-tmp.length())+"|\n";
		//
		tmp=formatNumberString(cnvrtNumToStrng(stdPR,BUFFER_SIZE));
		Output+="Std.Dev. |"+tmp+repeatString(" ",lnPR-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdSR,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnSR-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdZP,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnZP-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdQ,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnQ-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdsemMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";		
		tmp=formatNumberString(cnvrtNumToStrng(stdhMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdkMOB,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnMOB-tmp.length())+"|";
		tmp=formatNumberString(cnvrtNumToStrng(stdDIF,BUFFER_SIZE));
		Output+=tmp+repeatString(" ",lnDIF-tmp.length())+"|\n";
		//
		Output+=repeatString("-",118)+"|\n\n";
		// Electric Potential Profile (if generated)
		if(numProfilePnts[i][0]>0)
			{Sum=new double[numProfilePnts[i][0]];
			for(int j=0;j<numProfilePnts[i][0];j++){Sum[j]=0;}
			Output+="Electric Potential Profile\n";
			Output+="Distance_[A] Electric_Potential_[V] Standard_Deviation\n";
			for(int j=0;j<Z.numFiles;j++)
				{if(j==0)
					{for(int k=0;k<numProfilePnts[i][j];k++){Output+=position[i][j][k]+"|";}
					Output+="\n";}
				tmp=fNm[j];
				Output+=tmp+repeatString(" ",9-tmp.length())+"|";
				for(int k=0;k<numProfilePnts[i][j];k++)
					{tmp=formatNumberString(cnvrtNumToStrng(electricPotential[i][j][k],BUFFER_SIZE));
					Output+=tmp+"|";
					Sum[k]+=electricPotential[i][j][k];}
				Output+="\n";}
			//
			for(int j=0;j<numProfilePnts[i][0];j++)
				{avgPot=Sum[j]/Z.numFiles;
				dArr=new double[Z.numFiles];
				for(int k=0;k<Z.numFiles;k++){dArr[k]=electricPotential[i][k][j];}
				stdPot=calc_std_dev(dArr,Z.numFiles,avgPot);
				delete [] dArr;
				Output+=position[i][0][j]+"|"+formatNumberString(cnvrtNumToStrng(avgPot,BUFFER_SIZE))+"|"+formatNumberString(cnvrtNumToStrng(stdPot,BUFFER_SIZE))+"\n";
				}
			delete [] Sum;
			Output+="\n";}
		}
	// Write Output to File
	ofstream fOut;
	fOut.open(outFile.c_str(),ofstream::out|ofstream::trunc);
	if(fOut.fail()){cerr<<"ERROR in ZPRED\nZPRED Output file could not be opened.\n"<<outFile; exit(EXIT_FAILURE);}
	fOut<<Output; fOut.close();
	cerr<<"Output stored in:\n"<<outFile<<"\n";
}

double calc_average(double* X,int Sz)
	{double Output=0;
	int Counter=0;
	for(int i=0;i<Sz;i++)
		{if(!isnan(X[i]))
			{Output+=X[i];
			Counter++;}
		}
	if(Counter==0){return 0;}
	return Output/Counter;}

double calc_std_dev(double* X,int Sz,double Avg)
	{double Output=0;
	int Counter=0;
	for(int i=0;i<Sz;i++)
		{if(!isnan(X[i]))
			{Output+=(X[i]-Avg)*(X[i]-Avg);
			Counter++;}
		}
	if(Counter==1){return sqrt(Output/Counter);}
	else if(Counter==0){return 0;}
	else{return sqrt(Output/(Counter-1));}}
	
double interpolate(double x,double x1,double x2,double y1,double y2){double output=(y2-y1)*(x-x1)/(x2-x1) + y1;return output;}

string array2String(int* Data,int numPnts,string delimiter){string Output="";for(int i=0;i<numPnts;i++){Output+=cnvrtNumToStrng(Data[i],0)+delimiter;}return Output;}

bool IN_LIST(string X,string list,int N,string delimiter)
	{// Is X in list?
	bool Output=false;
	string* L,tmp;
	if(N==0){Output=false;}
	else{L=fill_string_array(list,N,delimiter);
		for(int i=0;i<N;i++)
			{tmp=L[i];
			if(tmp.compare(X)==0){Output=true;break;}}}
	return Output;}

bool IN_STRING_ARRAY(string X,string* L,int N)
	{// Is X in array?
	bool Output=false;
	string tmp;
	if(N==0){Output=false;}
	else{for(int i=0;i<N;i++)
			{tmp=L[i];
			if(tmp.compare(X)==0){Output=true;break;}}}
	return Output;}

void copyFile(string inFile,string outFile)
	{long fileSz=getFileSize(inFile);
	char* buf=new char[fileSz];
	ifstream fIn;
	bool ATTEMPTING=true;
	int numTries=100000,Counter=0;
	int Err;char errMsg[256];
	while(ATTEMPTING)
		{fIn.open(inFile.c_str(),ios::in|ios::binary);
		if(!fIn.fail()){fIn.read(buf,fileSz);fIn.close();ATTEMPTING=false;break;}
		else{Counter++;}
		if(Counter>=numTries)
			{Err=errno;erase_display();
			cerr<<"ERROR in copyFile!\nInput file could not be opened.\n"<<inFile<<endl;
			cerr<<strerror_r(Err,errMsg,256)<<"\n";
			exit(EXIT_FAILURE);}
		}
	
	ATTEMPTING=true;Counter=0;
	ofstream fOut;
	while(ATTEMPTING)
		{fOut.open(outFile.c_str(),ios::out|ios::binary);
		if(!fOut.fail()){fOut.write(buf,fileSz);fOut.close();ATTEMPTING=false;break;}
		else{Counter++;}
		if(Counter>=numTries)
			{Err=errno;erase_display();
			cerr<<"ERROR in copyFile!\nOutput file could not be opened.\n"<<outFile<<endl;
			cerr<<strerror_r(Err,errMsg,256)<<"\n";
			exit(EXIT_FAILURE);}
		}
	}

string checkFilePathParantheses(string f)
	{string Output=f;
	int pos=Output.find("(",0);
	bool SEARCHING=true;
	while(SEARCHING)
		{if(pos!=string::npos)
			{Output.replace(pos,1,"\\(");
			pos=Output.find(")",pos+1);
			if(pos!=string::npos){Output.replace(pos,1,"\\)");}
			else{cerr<<"Error in checkFilePathParantheses!\nUnbalanced parantheses present.\n";exit(EXIT_FAILURE);}
			pos=Output.find("(",pos);}
		else{SEARCHING=false;break;}}
	return Output;}

string getBaseFolder(string f)
	{int pos=f.rfind("/",f.length()-1);
	return f.substr(0,pos)+"/";}

string cnvrtNumToStrng(int Num,int numberAfterDecimalpoint){stringstream ss;ss.setf(ios::fixed);if(numberAfterDecimalpoint>0){ss.setf(ios::showpoint);}ss.precision(numberAfterDecimalpoint);ss<<Num;return ss.str();}

string cnvrtNumToStrng(double Num,int numberAfterDecimalpoint){stringstream ss;ss.setf(ios::fixed);if(numberAfterDecimalpoint>0){ss.setf(ios::showpoint);}ss.precision(numberAfterDecimalpoint);ss<<Num;return ss.str();}

string cnvrtNumToStrng(long double Num,int numberAfterDecimalpoint){stringstream ss;ss.setf(ios::fixed);if(numberAfterDecimalpoint>0){ss.setf(ios::showpoint);}ss.precision(numberAfterDecimalpoint);ss<<Num;return ss.str();}

string cnvrtNumToStrng(float Num,int numberAfterDecimalpoint){stringstream ss;ss.setf(ios::fixed);if(numberAfterDecimalpoint>0){ss.setf(ios::showpoint);}ss.precision(numberAfterDecimalpoint);ss<<Num;return ss.str();}

int count_delimiter(string Data,string delimiter){int Counter=0;string tmp="";for(int i=0;i<Data.length();i++){tmp=Data[i];if(tmp.compare(delimiter)==0){Counter++;}}return Counter;}

string checkWhiteSpaceInFilePath(string iFile)
	{int pos=iFile.find(" ",0),pos2,pos3;
	bool CHECKING=true;
	string tmp=iFile,tmp2;
	while(CHECKING)
		{if(pos!=string::npos)
			{// White Space Found, Add ' ' to folder Name
			// 1st /
			pos2=tmp.rfind("/",pos);
			// 2nd /
			pos3=tmp.find("/",pos);
			// Add Single Quotes to tmp
			tmp2=tmp.substr(0,pos2+1)+"\'"+tmp.substr(pos2+1,pos3-pos2-1)+"\'"+tmp.substr(pos3,tmp.length()-pos3);
			tmp=tmp2;
			//inputVal=inputVal.substr(1,inputVal.length()-1);pos=inputVal.find(" ",0);
			pos=tmp.find(" ",pos+3);
			}
		else if(pos==0)
			{// Whitespace Preceeding filepath, remove it
			tmp=tmp.substr(1,tmp.length()-1);
			pos=tmp.find(" ",0);
			}
		else{CHECKING=false;break;}
		}
	return tmp;}

void erase_display(){cerr<<"\033[2J\033[1;H";}

string getFileName(string filePath)
	{string Output;
	int pos=filePath.rfind("/");
	Output=filePath.substr(pos+1,filePath.length()-pos-1);
	return Output;}

double* fill_double_array(string Data,int numPnts,string delimiter){double* Output=new double[numPnts];string bld="",tmp="";int Counter=0;for(int i=0;i<Data.length();i++){tmp=Data[i];if(tmp.compare(delimiter)==0 && Counter<numPnts){Output[Counter]=strtod(bld.c_str(),NULL);Counter++;bld="";}else{bld+=Data[i];}}return Output;}

int* fill_int_array(string Data,int numPnts,string delimiter){int* Output=new int[numPnts];string bld="",tmp="";int Counter=0;for(int i=0;i<Data.length();i++){tmp=Data[i];if(tmp.compare(delimiter)==0 && Counter<numPnts){Output[Counter]=atoi(bld.c_str());Counter++;bld="";}else{bld+=Data[i];}}return Output;}

string* fill_string_array(string Data,int numPnts,string delimiter){string* Output=new string[numPnts];string bld="",tmp="";int Counter=0;for(int i=0;i<Data.length();i++){tmp=Data[i];if(tmp.compare(delimiter)==0 && Counter<numPnts){Output[Counter]=bld;Counter++;bld="";}else{bld+=Data[i];}}return Output;}

string formatNumberString(string Num)
	{string Output,tmp,tmp2;
	/* Check if contains decimal*/
	int i,pos=Num.find(".",0);
	if(pos==string::npos)
		{/* Number Value is an integer with no decimal*/
		for(i=0;i<Num.length();i++)
			{tmp=Num[i];
			/* Find 1st Non-Zero Number*/
			if(tmp.compare("0")!=0){break;}}
		Output=Num.substr(i,Num.length()-i);}
	else if(pos==0)
		{/* Precede decimal with zero*/
		Output="0";
		for(i=Num.length();i>0;i--)
			{tmp=Num[i-1];
			/* Search in reverse for 1st Non-Zero Number*/
			if(tmp.compare("0")!=0){break;}}
		Output+=Num.substr(0,i);}
	else{/* Number holds form XXX.XXX*/
		for(i=0;i<pos;i++)
			{tmp=Num[i];
			/* Find 1st Non-Zero Number*/
			if(tmp.compare("0")!=0){break;}}
		/* Define value preceding decimal*/
		if(i==pos){/* Only Zeros found up to the decimal*/Output="0";}
		else{Output=Num.substr(i,pos-i);}
		for(i=Num.length();i>pos;i--)
			{tmp=Num[i-1];
			/* Search in reverse for 1st Non-Zero Number*/
			if(tmp.compare("0")!=0){break;}}
		tmp2=Num.substr(pos,i-pos);
		/* will contain .XXX*/
		if(tmp2.length()>1){Output+=tmp2;}}
	return Output;}

long getFileSize(string inFile)
	{FILE *fI;
	int Err;
	char errMsg[256];
	fI=fopen(inFile.c_str(),"r");
	if(fI==NULL)
		{Err=errno;erase_display();
		cerr<<"ERROR in getFileSize!\nCould not open input file: "<<inFile<<endl;		
		cerr<<strerror_r(Err,errMsg,256)<<"\n";
		exit(EXIT_FAILURE);}
	fseek(fI,0,SEEK_END);
	long Output=ftell(fI);
	fclose(fI);
	return Output;}

string makeUpperCase(string X){string Output="";char letter,c;for(int i=0;i<X.length();i++){letter=X[i];Output+=toupper(letter);}return Output;}

string makeWhiteSpace(int Sz){string output="";for(int i=0;i<Sz;i++){output+=" ";}return output;}

string makeHTMLWhiteSpace(int Sz){string output="";for(int i=0;i<Sz;i++){output+="&nbsp;";}return output;}

zInput read_zpred_input_file(string inFile)
	{// , = internal delimiter| ; = external delimiter between solution conditinos
	zInput D;
	// Initialize Default Values
	//D.id="NoId";
	//D.name="molecule";
	D.numSolCond=0;
	D.numFiles=0;
	D.SC.apbsExecutable="";
	D.SC.multivalueExecutable="";
	D.SC.hydroproExecutable="";
	D.SC.msmsExecutable="";
	D.SC.msmsAtmTypeNumbers="";
	D.SC.msmsPdbToXyzr="";
	D.SC.msmsPdbToXyzrn="";
	D.SC.pdb2pqr="";			// main.py of PDB2PQR
	D.msms.PDB="";
	D.msms.pdbFile="";
	D.msms.pdb_msmsFldr="";
	D.msms.pdb_surfFldr="";
	D.msms.surfPointDensity="1.000000";
	D.msms.surfPointHiDensity="3.000000";
	D.hydroproCalcType="1";
	D.saveTemps=false; // ?3?
	D.pdie="4.0";
	D.dime_x="161"; D.dime_y="161"; D.dime_z="161";
	D.maxThreads=MAX_THREADS;
	D.RUN_APBS=true;
	D.RUN_PDB2PQR=true;
	D.RUN_HYDROPRO=false;
	D.RUN_HULLRAD=true;
	D.RUN_ZPRED=true;
	D.RUN_COLLIDE=true;
	D.outputTitle="Output/";
	D.numApbsWriteTypes=1;
	D.apbsWriteTypes=fill_string_array("pot;",1,";");
	D.forceField="PARSE";
	D.plot="";

	ifstream fIn;
	fIn.open(inFile.c_str());
	if(fIn.fail()){cerr<<"ERROR in read_zpred_input_file!\nInput file could not be opened.\n"<<inFile<<endl;exit(EXIT_FAILURE);}
	int Sz=10000,pos,oldPos,N;
	char Val[Sz];
	string bld,tmp,inputName,inputVal,delimiter="",*sArr;
	fIn.getline(Val,Sz);
	bool CHECKING;
	while(!fIn.eof())
		{tmp=Val;
		pos=tmp.find(".",0);
		if(pos!=string::npos && pos==0)
			{// Start of Line contains a period, now check if line defines an input parameter
			pos=tmp.find(":",pos);	// defines end of input parameter name
			if(pos!=string::npos)
				{// Extract Input Parameter Name
				inputName=tmp.substr(tmp.find(".",0)+1,pos-tmp.find(".",0)-1);
				inputName=makeUpperCase(inputName);
				// Extract Input Parameter Value(s)
				inputVal=tmp.substr(pos+1,tmp.length()-pos-1);
				// Check for & Remove Preceding WhiteSpace(s)
				CHECKING=true;
				pos=inputVal.find(" ",0);
				if(inputName.compare("FILES")==0||inputName.compare("APBSEXECUTABLE")==0||inputName.compare("MULTIVALUEEXECUTABLE")==0||inputName.compare("HYDROPROEXECUTABLE")==0||inputName.compare("MSMSEXECUTABLE")==0||inputName.compare("MSMSATMTYPENUMBERS")==0||inputName.compare("MSMSPDBTOXYZR")==0||inputName.compare("MSMSPDBTOXYZRN")==0||inputName.compare("PDB2PQR")==0)
					{// Remove preceeding white space if present
					if(pos==0){inputVal=inputVal.substr(1,inputVal.length()-1);}
					}
				else
					{
					while(CHECKING)
						{if(pos!=string::npos){inputVal=inputVal.substr(1,inputVal.length()-1);pos=inputVal.find(" ",0);}
						else{CHECKING=false;break;}}
					}
				if(inputVal.length()!=0)
					{// Identify Parameter and Load Values
					if(inputName.compare("ID")==0)
						{// Id for Computation (for organization purposes)
						D.numSolCond=count_delimiter(inputVal,";");
						D.id=fill_string_array(inputVal,D.numSolCond,";");}
					else if(inputName.compare("FILES")==0)
						{// Acquire PDB File Names
						D.numFiles=count_delimiter(inputVal,";");
						D.files=fill_string_array(inputVal,D.numFiles,";");}
					else if(inputName.compare("PH")==0)
						{// Array of pH Values
						D.pH=fill_string_array(inputVal,D.numSolCond,";");}
					else if(inputName.compare("SOLUTE")==0)
						{// Array of Solute Names ,;,;,;
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'solute\' names ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						sArr=fill_string_array(inputVal,N,";");
						D.solute=new string*[N];
						D.numSolute=new int[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.numSolute[i]=count_delimiter(tmp,",");
							D.solute[i]=fill_string_array(tmp,D.numSolute[i],",");}
						delete [] sArr;}
					else if(inputName.compare("SOLUTECONC")==0)
						{// Array of Solute Concentrations soluteConc[numSolute][numSoluteConc]  (Ion#1Conc,Ion#1Conc,;Ion#2Conc,;)
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'soluteConc\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						sArr=fill_string_array(inputVal,N,";");
						D.soluteConc=new double*[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.soluteConc[i]=fill_double_array(tmp,D.numSolute[i],",");}
						delete [] sArr;}
					else if(inputName.compare("SOLUTECONCTYPE")==0)
						{// Specifies type of concentration of soluteConc (always one value)
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'soluteConcType\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						/*sArr=fill_string_array(inputVal,N,";");
						D.soluteConcType=new string*[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.soluteConcType[i]=fill_string_array(tmp,D.numSolute[i],",");}
						delete [] sArr;
						*/
						D.soluteConcType=fill_string_array(inputVal,N,";");
						}
					else if(inputName.compare("SOLVENT")==0)
						{// Array of Solvent Names ,;,;,;
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'solvent\' names ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						sArr=fill_string_array(inputVal,N,";");
						D.solvent=new string*[N];
						D.numSolvent=new int[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.numSolvent[i]=count_delimiter(tmp,",");
							D.solvent[i]=fill_string_array(tmp,D.numSolvent[i],",");}
						delete [] sArr;}
					else if(inputName.compare("SOLVENTCONC")==0)
						{// Array of Solvent Concentrations
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'solventConc\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						sArr=fill_string_array(inputVal,N,";");
						D.solventConc=new double*[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.solventConc[i]=fill_double_array(tmp,D.numSolvent[i],",");}
						delete [] sArr;}
					else if(inputName.compare("SOLVENTCONCTYPE")==0)
						{// Specifies type of concentration of solventConc
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'solventConcType\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						/*sArr=fill_string_array(inputVal,N,";");
						D.solventConcType=new string*[N];
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							D.solventConcType[i]=fill_string_array(tmp,D.numSolvent[i],",");}
						delete [] sArr;*/
						D.solventConcType=fill_string_array(inputVal,N,";");
						}
					else if(inputName.compare("TEMPERATURE")==0)
						{// Array of Temperatures (Kelvin)
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'temperature\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						D.temperature=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("PROTEINCONC")==0)
						{// Protein Concentration (mg/mL)
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'proteinConc\' ("<<N<<") does not match number of solution conditions.\nInput:"<<inputVal<<"\n";exit(EXIT_FAILURE);}
						D.proteinConc=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("APBSWRITETYPES")==0)
						{// APBS Output Write Types
						N=count_delimiter(inputVal,";");
						D.numApbsWriteTypes=N;
						delete [] D.apbsWriteTypes;
						D.apbsWriteTypes=fill_string_array(inputVal,N,";");}
					else if(inputName.compare("APBSEXECUTABLE")==0)
						{// APBS Executable File Path
						D.SC.apbsExecutable=inputVal;}
					else if(inputName.compare("MULTIVALUEEXECUTABLE")==0)
						{// APBS Multivalue Executable File Path
						D.SC.multivalueExecutable=inputVal;}
					else if(inputName.compare("HYDROPROEXECUTABLE")==0)
						{// HYDROPRO Executable File Path
						D.SC.hydroproExecutable=inputVal;}
					else if(inputName.compare("MSMSEXECUTABLE")==0)
						{// MSMS Executable File Path
						D.SC.msmsExecutable=inputVal;}
					else if(inputName.compare("MSMSATMTYPENUMBERS")==0)
						{// MSMS Executable File Path
						D.SC.msmsAtmTypeNumbers=inputVal;}
					else if(inputName.compare("MSMSPDBTOXYZR")==0)
						{// MSMS Executable File Path
						D.SC.msmsPdbToXyzr=inputVal;}
					else if(inputName.compare("MSMSPDBTOXYZRN")==0)
						{// MSMS Executable File Path
						D.SC.msmsPdbToXyzrn=inputVal;}
					else if(inputName.compare("PDB2PQR")==0)
						{// File Path to PDB2PQR python script
						D.SC.pdb2pqr=inputVal;}
					else if(inputName.compare("MSMSSURFPOINTDENSITY")==0)
						{// MSMS Parameter: Low Surface Density
						D.msms.surfPointDensity=inputVal;}
					else if(inputName.compare("MSMSSURFPOINTHIDENSITY")==0)
						{// MSMS Parameter: High Surface Density
						D.msms.surfPointHiDensity=inputVal;}
					else if(inputName.compare("HYDROPROCALCTYPE")==0)
						{// HYDROPRO Parameter: Calculation Type selects model
						D.hydroproCalcType=inputVal;}
					else if(inputName.compare("FORCEFIELD")==0)
						{// PDB2PQR Force Field
						D.forceField=inputVal;}
					else if(inputName.compare("SAVETEMPS")==0)
						{// Flag for Saving Files Used in the Computation
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.saveTemps=false;}
						else{D.saveTemps=true;}}
					else if(inputName.compare("PDIE")==0)
						{// APBS Parameter: Protein Relative Dielectric
						D.pdie=inputVal;}
					else if(inputName.compare("DIME_X")==0)
						{// APBS Parameter: Number of X-Axis Grid Points
						D.dime_x=inputVal;}
					else if(inputName.compare("DIME_Y")==0)
						{// APBS Parameter: Number of Y-Axis Grid Points
						D.dime_y=inputVal;}
					else if(inputName.compare("DIME_Z")==0)
						{// APBS Parameter: Number of Z-Axis Grid Points
						D.dime_z=inputVal;}
					else if(inputName.compare("RUN_APBS")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_APBS=false;}
						else{D.RUN_APBS=true;}}
					else if(inputName.compare("RUN_PDB2PQR")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_PDB2PQR=false;}
						else{D.RUN_PDB2PQR=true;}}
					else if(inputName.compare("RUN_HYDROPRO")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_HYDROPRO=false;}
						else{D.RUN_HYDROPRO=true;}}
					else if(inputName.compare("RUN_HULLRAD")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_HULLRAD=false;}
						else{D.RUN_HULLRAD=true;}}
					else if(inputName.compare("RUN_ZPRED")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_ZPRED=false;}
						else{D.RUN_ZPRED=true;}}
					else if(inputName.compare("RUN_COLLIDE")==0)
						{// ZPRED Control Paramater
						inputVal=makeUpperCase(inputVal);
						if(inputVal.compare("FALSE")==0){D.RUN_COLLIDE=false;}
						else{D.RUN_COLLIDE=true;}}
					else if(inputName.compare("OUTPUTTITLE")==0)
						{// ZPRED Output Folder Title
						D.outputTitle=inputVal;}
					else if(inputName.compare("MAXTHREADS")==0)
						{// ZPRED Control Paramater
						D.maxThreads=atoi(inputVal.c_str());}
					else if(inputName.compare("DENSITY")==0)
						{// User Specified Solution Property
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'density\' ("<<N<<") does not match number of solution conditions.\n";exit(EXIT_FAILURE);}
						D.density=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("DIELECTRIC")==0)
						{// User Specified Solution Property
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'density\' ("<<N<<") does not match number of solution conditions.\n";exit(EXIT_FAILURE);}
						D.dielectric=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("INFLATIONDISTANCE")==0)
						{// User Specified Solution Property
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'density\' ("<<N<<") does not match number of solution conditions.\n";exit(EXIT_FAILURE);}
						D.inflationDistance=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("VISCOSITY")==0)
						{// User Specified Solution Property
						N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'density\' ("<<N<<") does not match number of solution conditions.\n";exit(EXIT_FAILURE);}
						D.viscosity=fill_double_array(inputVal,N,";");}
					else if(inputName.compare("GENERATEPROFILE")==0)
						{N=count_delimiter(inputVal,";");
						if(N!=D.numSolCond){cerr<<"ERROR in read_zpred_input_file!\nNumber of \'generateProfile\' ("<<N<<") does not match number of solution conditions.\n";exit(EXIT_FAILURE);}
						D.GENERATE_POT_PROFILE=new bool[N];
						sArr=fill_string_array(inputVal,N,";");
						for(int i=0;i<N;i++)
							{tmp=sArr[i];
							if(tmp.compare("true")==0){D.GENERATE_POT_PROFILE[i]=true;}
							else if(tmp.compare("false")==0){D.GENERATE_POT_PROFILE[i]=false;}
							else{cerr<<"ERROR in read_zpred_input_file!\nNumber of \'generateProfile\' has incorrect values.\n";exit(EXIT_FAILURE);}
							}
						delete [] sArr;}
					else if(inputName.compare("PLOT")==0)
						{// Plotting Feature
						D.plot=inputVal;}
					else{cerr<<"ERROR in read_zpred_input_file!\nUnrecognized Parameter ("<<inputName<<")."<<endl;exit(EXIT_FAILURE);}
					}
				}
			}
		fIn.getline(Val,Sz);}
	fIn.close();
	return D;}

string repeatString(string Input,int Num){string Output="";for(int i=0;i<Num;i++){Output+=Input;}return Output;}

double calc_distance(Vec Vec1,Vec Vec2)
    {return sqrt((Vec2.x-Vec1.x)*(Vec2.x-Vec1.x)+(Vec2.y-Vec1.y)*(Vec2.y-Vec1.y)+(Vec2.z-Vec1.z)*(Vec2.z-Vec1.z));}

zOutput read_zpred_output_file(string zOutFile)
	{// Define and Initialize Values
	zOutput D;
	D.proteinName="";
	D.proteinRadius=-1;
	D.solvatedRadius=-1;
	D.zetaPotential=NAN;
	D.charge=NAN;
	D.diffusivity=NAN;
	D.semMobility=NAN;
	D.Xsp="";
	D.solution.pH="";
	D.solution.temperature="";
	D.solution.dielectric="";
	D.solution.viscosity="";
	D.solution.density="";
	D.solution.numSolute=-1;
	D.solution.numSolvent=-1;
	D.solution.debyeLength="";

	ifstream fIn;
	fIn.open(zOutFile.c_str());
	if(fIn.fail()){cerr<<"ERROR in read_zpred_output_file!\nZPRED output file could not be opened.\n"<<zOutFile<<endl;exit(EXIT_FAILURE);}
	int Sz=15000,pos;
	char Val[Sz];
	bool CHECKING,SPHERE=false,CYLINDER=false;
	string bld="",tmp="",inputName="",inputVal="",delimiter=";";
	string *sArr;
	double *dArr;
	fIn.getline(Val,Sz);
	while(!fIn.eof())
		{tmp=Val;
		pos=tmp.find(".",0);
		if(pos!=string::npos && pos==0)
			{// Line contains a period, now check if line defines an input parameter
			pos=tmp.find(":",pos);	// defines end of input parameter name
			if(pos!=string::npos)
				{// Extract Input Parameter Name
				inputName=tmp.substr(tmp.find(".",0)+1,pos-tmp.find(".",0)-1);
				// Extract Input Parameter Value(s)
				inputVal=tmp.substr(pos+1,tmp.length()-pos-1);
				// Check for Preceding WhiteSpace(s)
				CHECKING=true;
				pos=inputVal.find(" ",0);
				while(CHECKING)
					{if(pos!=string::npos){inputVal=inputVal.substr(1,inputVal.length()-1);pos=inputVal.find(" ",pos+1);}
					else{CHECKING=false;break;}}
				if(inputVal.length()!=0)
					{// Identify Parameter and Load Values
					if(inputName.compare("shape")==0)
						{// Shape Descriptor
						if(inputVal.compare("sphere")==0){SPHERE=true;}
						else if(inputVal.compare("cylinder")==0){CYLINDER=true;}
						}
					else if(inputName.compare("proteinRadius")==0)
						{// Anhydrous Protein Radius (A)
						D.proteinRadius=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("proteinName")==0)
						{// Name of Specific PDB File under Assessment
						D.proteinName=inputVal;}
					else if(inputName.compare("solCondNum")==0)
						{// Name of Specific PDB File under Assessment
						D.solCondNum=inputVal;}
					else if(inputName.compare("solvatedRadius")==0)
						{// Solvated Protein Radius (A)
						D.solvatedRadius=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("charge")==0)
						{// Protein Net Charge Valence [e]
						D.charge=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("diffusivity")==0)
						{// Protein Diffusivity [m^2/s]
						D.diffusivity=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("henryMobility")==0)
						{// Ideal Single-Particle Electrophoretic Mobility [umcm/Vs]
						if(inputVal.compare("NaN")==0)
							{D.henryMobility=nan("");}
						else
							{D.henryMobility=strtod(inputVal.c_str(),NULL);}
						}
					else if(inputName.compare("kuwabaraMobility")==0)
						{// Kuwabara Concentration-Corrected Electrophoretic Mobility [umcm/Vs]
						if(inputVal.compare("NaN")==0)
							{D.kuwabaraMobility=nan("");}
						else
							{D.kuwabaraMobility=strtod(inputVal.c_str(),NULL);}
						}
					else if(inputName.compare("semMobility")==0)
						{// Ideal Single-Particle Electrophoretic Mobility [umcm/Vs]
						if(inputVal.compare("NaN")==0)
							{D.semMobility=nan("");}
						else
							{D.semMobility=strtod(inputVal.c_str(),NULL);}
						}
					//else if(SPHERE && inputName.compare("semMobility2")==0)
					//	{// Kuwabara Concentration-Corrected Electrophoretic Mobility [umcm/Vs]
					//	D.mobility=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("Xsp")==0)
						{// Hydration Layer Thickness (A)
						D.Xsp=inputVal;}
					else if(inputName.compare("zetaPotential")==0)
						{// ZPRED Computed Zeta Potential (V)
						D.zetaPotential=strtod(inputVal.c_str(),NULL);}
					else if(inputName.compare("debyeLength")==0)
						{// Solution Debye Length (A)
						D.solution.debyeLength=inputVal;}
					else if(inputName.compare("pH")==0)
						{// Solution pH
						D.solution.pH=inputVal;}
					else if(inputName.compare("temperature")==0)
						{// Solution Temperature [K]
						D.solution.temperature=inputVal;}
					else if(inputName.compare("dielectric")==0)
						{// Solution Relative Dielectric
						D.solution.dielectric=inputVal;}
					else if(inputName.compare("viscosity")==0)
						{// Solution Viscosity [Pa s]
						D.solution.viscosity=inputVal;}
					else if(inputName.compare("density")==0)
						{// Solution Density [kg/L]
						D.solution.density=inputVal;}
					else if(inputName.compare("solvent")==0)
						{// Solution Components (Solvent Names)
						D.solution.numSolvent=count_delimiter(inputVal,delimiter);
						D.solution.solvent=fill_string_array(inputVal,D.solution.numSolvent,delimiter);}
					else if(inputName.compare("solventConc")==0)
						{// Solution Components (Solvent Concentrations) [Mole Fraction]
						D.solution.numSolvent=count_delimiter(inputVal,delimiter);
						D.solution.solventConc=fill_string_array(inputVal,D.solution.numSolvent,delimiter);}
					else if(inputName.compare("solute")==0)
						{// Solution Components (Solute Names)
						D.solution.numSolute=count_delimiter(inputVal,delimiter);
						D.solution.solute=fill_string_array(inputVal,D.solution.numSolute,delimiter);}
					else if(inputName.compare("soluteConc")==0)
						{// Solution Components (Solute Concentrations) [Molar]
						D.solution.numSolute=count_delimiter(inputVal,delimiter);
						D.solution.soluteConc=fill_string_array(inputVal,D.solution.numSolute,delimiter);}
					else if(inputName.compare("generateProfile")==0)
						{if(inputVal.compare("false")==0){D.EP.numPnts=0;}
						else
							{D.EP.numPnts=count_delimiter(inputVal,";");
							D.EP.position=new double[D.EP.numPnts];
							D.EP.potential=new double[D.EP.numPnts];
							sArr=fill_string_array(inputVal,D.EP.numPnts,";");
							for(int i=0;i<D.EP.numPnts;i++)
								{tmp=sArr[i];
								dArr=fill_double_array(tmp,2,",");
								D.EP.position[i]=dArr[0];
								D.EP.potential[i]=dArr[1];
								delete [] dArr;}
							delete [] sArr;}
						}
					else{//cerr<<"ERROR in read_zpred_output_file!\nUnrecognized Parameter ("<<inputName<<").\n";exit(EXIT_FAILURE);
						}
					}
				}
			}
		fIn.getline(Val,Sz);}
	fIn.close();
	return D;}
