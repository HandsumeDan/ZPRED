clear
G_File=/usr/bin/g++
Fldr=$(pwd)/

C_File=$Fldr"gatherData.cpp"
X_File=$Fldr"gatherData.exe"
Fldr2=$Fldr"alglib/src/"
other_C_Files=""
cd $Fldr2
for file in *; do
	len=${#file}	
	ext=${file:(( $len - 3 )):3}
	if [ $ext == "cpp" ]
		then
			other_C_Files=$other_C_Files$Fldr2$file" "
	fi
done
cd $Fldr

#rm -f $X_File
# Compile & Run get_SES_Shell
#$G_File -std=gnu++11 -o $X_File -I$Fldr2 $C_File $other_C_Files -lm -w -lrt -lboost_system -lboost_filesystem -lcrypto -lpthread
#$G_File -std=gnu++11 -o $X_File $C_File
$X_File -i zpredInput.txt -o "BSA_Dimer_pH.txt" -z "/home/handsomedan/Desktop/ZPRED/BSA_Dimer_pH/Files/zpredOutFilesList.txt"
